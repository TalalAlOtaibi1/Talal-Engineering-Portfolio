%% Prepare Workspace
clc
clear
close
%% Q7, 8, and 9

% Setup all constants
d = 122.91
a = 89.82
t1 = deg2rad(17.8)

% Theoretically, theta_2's domain encompasses 0 through 360 degrees.
t2 = deg2rad(0:1:360) % 1 x 361 input

% a loop is not needed as the vectors can be divided and multiplied
% by one another using scalar operations
omega_2 = 1 %CCW

%% Vector loop 1 
b = sqrt(d.^2 + a.^2 - 2*a*d*cos(t2-t1)) % Law of cosines to evaluate b


t3 = (acos((a*cos(t2) - d*cos(t1))./b)) % find theta_3 using b

% evaluate omega 3
omega_3 = (a./b).*omega_2.*(cos(t2).*cos(t3) + sin(t2).*sin(t3)) 

% evaluate the sliding velocity
b_dot = (a.*omega_2.*cos(t2) - b.*omega_3.*cos(t3))./(sin(t3))


%% Vector Loop 2

% define lengths
L_4 = 146.55;
L_5 = 260 - d*cos(t1);
L_7 = 217.45 - b; % L_7 and b must add up to link 3 's length

% evaluate theta 4 based on vector loop
t4 = (acos((L_7.*cos(t3) + L_5)./(L_4))); 


% evaluate L_6 using previous values
L_6 = L_4.*sin(t4) - L_7.*sin(t3);

L_7_dot = -b_dot; % By differentiation, L_7_dot and the sliding velocity are
% magnitudinally equal but in opposing directions

% with L_7_dot, find the angular velocity of link 4

omega_4 = (L_7.*omega_3.*sin(t3) - L_7_dot.*cos(t3))./(L_4.*sin(t4));

% Finally, find L_6_dot, which is equal to the velocity of point c
L_6_dot = L_4.*omega_4.*cos(t4) - L_7.*omega_3.*cos(t3) - L_7_dot.*sin(t3);
v_c = L_6_dot;

% the moment arm at which force is applied measured from O_2
r_O2P = 55.15;

v_p = omega_2.*r_O2P;


MA = v_p./v_c; % Because Mechanical advantage is the ratio of F_out 
% divided by F_in, this simplifies to the ratio between v_p and v_c



figure(1)
plot(rad2deg(t2),v_c,'b-'); hold on

xlim([0 360])
xlabel('\theta_2 (degrees)')
ylabel('Velocity of Point C V_c (mm/s)')
title('Point C Velocity vs. Input Angle (\theta_2 (degrees)')

t2_calc = 106
v_c_calc = 6.0562
plot(t2_calc,v_c_calc, 'rx')
legend('Point C Velocity plot', 'v_c calculation data point', 'location','best')

figure(2)
plot(rad2deg(t2),MA,'b-'); hold on
t2_calc = 106;
MA_calc = 9.1064
plot(t2_calc,MA_calc, 'rx')

xlim([0 360])
xlabel('\theta_2 (degrees)')
ylabel('Mechanical Advantage')
title('Mechanical Advantage vs. (\theta_2 (degrees)')
legend('Mechanical Advantage Plot', 'Mechanical advantage calculation data point', 'location','northeast')

%% Q9 Remark
% The calculated data points intersect with the graphed figures, indicating
% a good extent of analytical accuracy and consistency.

%% Note
% The servo motor does not rotate the full 360 degrees. The arduino file
% explains the selected domain.
